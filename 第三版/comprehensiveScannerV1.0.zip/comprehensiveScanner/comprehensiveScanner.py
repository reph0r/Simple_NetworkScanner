#!/usr/bin/python3
# -*- coding:utf-8 -*-
# @author:CVultra
# @time:2022/7/5

#--------------------------------------------------------------
import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests

from lib.core1 import *
from lib.core2 import *
from lib.core3 import *
from lib.core4 import *
from lib.core5 import *


#--------------------------------------------------------------

#--------------------------------------------------------------
def Welcome():
    Welcome = """

/***
 *                    .::::.
 *                  .::::::::.
 *                 :::::::::::  
 *             ..:::::::::::'
 *           '::::::::::::'
 *             .::::::::::
 *        '::::::::::::::..
 *             ..::::::::::::.
 *           ``::::::::::::::::
 *            ::::``:::::::::'        .:::.
 *           ::::'   ':::::'       .::::::::.
 *         .::::'      ::::     .:::::::'::::.
 *        .:::'       :::::  .:::::::::' ':::::.
 *       .::'        :::::.:::::::::'      ':::::.
 *      .::'         ::::::::::::::'         ``::::.
 *  ...:::           ::::::::::::'              ``::.
 * ```` ':.          ':::::::::'                  ::::..
 *                    '.:::::'                    ':'````..
 */
        """

    print(Welcome)

#--------------------------------------------------------------

#--------------------------------------------------------------


#--------------------------------------------------------------


#--------------------------------------------------------------


#--------------------------------------------------------------
#5.域名反查IP
def get_ip(url):
    ip = socket.gethostbyname(url)
    print(ip)

#--------------------------------------------------------------
#6.whois查询
def check_whois(url):
    data = whois('%s'%url)
    print(data)

#--------------------------------------------------------------
def zym_check(url):
    urls = url.replace('www','')
    for zym_data in open('dic.txt'):
        zym_data = zym_data.replace('\n','')
        url = zym_data+urls
        try:
            ip = socket.gethostbyname(url)
            #r = requests.get('https://code.xueersi.com/')
            url = 'https://'+url
            r = requests.get(url)
            if(r.status_code == 200):
                print(url + '->' + ip)

            #time.sleep(0.2)
        except Exception as e:
            pass



#--------------------------------------------------------------

if __name__ == '__main__':

    Welcome()

    while True:
        print('''
        -----选择功能-----
        1.主机扫描
        2.端口扫描
        3.操作系统判断
        4.查询CDN
        5.域名反查IP
        6.whois查询
        7.子域名查询
        q.退出
        -----选择功能-----
        ''')
        choice = input("选择功能>>>")
        try:
            if choice == '1':
                print("Welcome to Host_Scanner,example:127.0.0.\n")
                ip_list = input("请输入您需要测试的IP段：>>>\n")
                for i in range(1, 256):
                    ip = (ip_list + str(i))
                    scan = threading.Thread(target=ping_ip, args=(ip,))
                    scan.start()
                    time.sleep(0.3)
            elif choice == '2':
                ScanPort().start()
            elif choice == '3':
                ip = input("请输入待判断操作系统的IP：>>>")
                guess_os_nmap()
            elif choice == '4':
                url = input("请输入待判断CDN的URL：>>>")
                if_have_cdn(url)
            elif choice == '5':
                url = input("请输入您需要查询IP的URL：>>>")
                get_ip(url)
            elif choice == '6':
                url = input("请输入您需要whois查询的URL：>>>")
                check_whois(url)
            elif choice == '7':
                url = input("请输入您需要查询子域名的域名：>>>")
                zym_check(url)

            elif choice == 'q':
                break
            else:
                print("输入错误！！")
        except Exception:
            pass
