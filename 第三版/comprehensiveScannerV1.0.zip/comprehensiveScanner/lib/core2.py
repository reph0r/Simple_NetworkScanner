import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests

#2.端口扫描
class ScanPort:
    def __init__(self):
        self.ip = None

    def scan_port(self, port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            res = s.connect_ex((self.ip, port))
            if res == 0:  # 端口开启
                print('Ip:{} Port:{} 端口 开启'.format(self.ip, port))
            #else:
                #print('Ip:{} Port:{}: IS NOT OPEN'.format(self.ip, port))
        except Exception as e:
            print(e)
        finally:
            s.close()

    def start(self):
        remote_server = input("输入要扫描的远程主机:")
        self.ip = socket.gethostbyname(remote_server)
        ports = [i for i in range(1, 1025)]
        socket.setdefaulttimeout(0.5)
        # 开始时间
        t1 = datetime.now()
        # 设置多进程
        threads = []
        pool = ThreadPool(processes=8)
        pool.map(self.scan_port, ports)
        pool.close()
        pool.join()

        print('端口扫描已完成，耗时：', datetime.now() - t1)