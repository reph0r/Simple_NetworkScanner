import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests

#4.识别CDN
def if_have_cdn(url):
    os_command = os.popen('nslookup %s'%url)
    #读取系统执行的命令
    os1 = os_command.read()
    #print(os1)
    number = os1.count(".")
    if number <= 10:
        print("[+]初步判断该网站没有CDN")
    else:
        print("[+]初步判断该网站具有CDN")