import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests

#1.主机扫描
def ping_ip(ip_str):
    cmd = ["ping", "-n 1", "-v 1", ip_str]
    resopnse = os.popen(" ".join(cmd)).readlines()
    ip_list = []
    flag = False
    for line in list(resopnse):
        if not line:
            continue
        if str(line).upper().find("TTL") >= 0:
            flag = True
            break

    if flag:
        print(ip_str+' 主机存活!')
        #ip_list.append(str(ip_str))
    else:
        print(ip_str,' 主机不存在!')
        pass
