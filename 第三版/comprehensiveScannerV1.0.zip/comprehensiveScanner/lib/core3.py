import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests

#3.操作系统判断
def guess_os_nmap(ip):
    """
    1.调用第三方库nmap进行系统扫描，判断操作系统
    2，如果再Windows系统下，需要先行安装ncap软件，才能正确执行代码
    :param ip:
    :return:
    """
    nm = nmap.PortScanner()
    try:
        result = nm.scan(hosts=ip,arguments='-0')
        os = result["scan"][ip]['osmatch'][0]['name']
        time.sleep(0.1)
        print(ip,os)
    except:
        pass