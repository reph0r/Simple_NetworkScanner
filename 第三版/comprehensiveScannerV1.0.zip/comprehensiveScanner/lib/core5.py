import nmap
import sys
from optparse import OptionParser
from scapy.all import *
import time
import os
import threading
import socket
from datetime import datetime
from multiprocessing.dummy import Pool as ThreadPool
from whois import *
import requests


#5.域名反查IP
def get_ip(url):
    ip = socket.gethostbyname(url)
    print(ip)